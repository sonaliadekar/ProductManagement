﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ProductManagement.Models
{
    public class ProductModel
    {
        public int ID { get; set; }

        [Required]
        public int CategoryId { get; set; }
        
        [Required]
        [StringLength(500, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 5)]
        [Display(Name = "Product Name")]
        public string Name { get; set; }

        [Required]
        public string Description { get; set; }

        [Required]
        [StringLength(50, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 3)]
        public string SKU { get; set; }

        [Required]
        [StringLength(500, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 5)]
        [Display(Name = "Image")]
        public string ImagePath { get; set; }
        [Required]       
        public decimal SellingPrice { get; set; }
        [Required]
        public int AvailableQty { get; set; }

        [Required]
        public string Type { get; set; }

        public decimal Weight { get; set; }
        public int Length { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
        public Nullable<decimal> ShippingCost { get; set; }

        public virtual category category { get; set; }
        public SelectList lstDropdown;
    }

    public class CategoryDropDown
    {
        public string Text { get; set; }
        public string Value { get; set; }
    }
}