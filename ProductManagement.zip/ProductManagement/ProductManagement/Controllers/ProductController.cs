﻿using ProductManagement.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ProductManagement.Controllers
{
    public class ProductController : Controller
    {
        private ShoppingCartEntities entities = new ShoppingCartEntities();
        // GET api/product
        public ActionResult Index()
        {
            
            return View(entities.Products.ToList());
        }

        public ActionResult AddProduct()
        {
            ProductModel pModel=new ProductModel();
            pModel.lstDropdown = new SelectList(entities.categories.ToList(), "ID", "Name"); // model binding
            return View(pModel);
        }

        [HttpPost]
        public ActionResult AddProduct(ProductModel model, HttpPostedFileBase file)
        {
            model.ImagePath = Path.Combine(("~/Images/"), file.FileName);
            //shipping cost
            if (model.Type=="Physical")
            {
                decimal weight = 0;
                decimal volumetricWeight = (model.Length * model.Width * model.Height) / 5000;
                if (model.Weight > volumetricWeight)
                {
                    weight = model.Weight;
                }
                else
                    weight = volumetricWeight;

                model.ShippingCost = weight * 50;
            }
            else if (model.Type == "Virtual")
            {
                decimal price = 0;
                decimal avgSellingPrice = model.SellingPrice * 10 / 100;
                if (avgSellingPrice > 50)
                {
                    price = avgSellingPrice;
                }
                else
                    price = 50;

                model.ShippingCost = price;
            }

            Product objProduct = new Product();
            objProduct.CategoryId = model.CategoryId;
            objProduct.Name = model.Name;
            objProduct.Description = model.Description;
            objProduct.SKU = model.SKU;
            objProduct.ImagePath = model.ImagePath;
            objProduct.SellingPrice = model.SellingPrice;
            objProduct.AvailableQty = model.AvailableQty;
            objProduct.Type = model.Type;
            objProduct.Weight = model.Weight;
            objProduct.Length = model.Length;
            objProduct.Width = model.Width;
            objProduct.Height = model.Height;
            objProduct.ShippingCost = model.ShippingCost;

            entities.Products.Add(objProduct);
            entities.SaveChanges();
            return RedirectToAction("Index");
        }
       

        // DELETE api/product/5
        public ActionResult Delete(int id)
        {
            entities.Products.Remove(entities.Products.Single(a => a.ID == id));
            entities.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
