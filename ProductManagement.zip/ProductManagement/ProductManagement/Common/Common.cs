﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductManagement.Common
{
    public class Common
    {
        public enum ProductType
        {
            Physical=1,
            Virtual=2
        }
    }
}